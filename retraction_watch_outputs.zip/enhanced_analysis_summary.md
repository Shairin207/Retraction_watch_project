# Retraction Watch Data Analysis — Enhanced Independent Version

## Executive Summary
The analysis retained 71,738 valid records from 72,001 raw CSV rows. Formal retractions account for 92.68% of cleaned records and form the primary inferential population. The median publication-to-retraction lag is 1.34 years, while the 90th percentile is 6.00 years, confirming a strongly right-skewed timing distribution.

## Preprocessing
Completely empty rows and columns were removed, strings were standardized, identifier placeholders were normalized, PubMed ID value 0 was treated as unavailable, dates were parsed, negative lag values were excluded from timing analysis, duplicate Record IDs were checked, and multi-value fields were parsed without inventing missing identifiers.

## EDA and Critical Analysis
The project examines notice composition, annual trends, publishers, journals, countries, subjects, article types, reasons, publication-to-notice lag, reason co-occurrence, identifier coverage, collaboration structure, effect sizes, recent reason shifts, subject–reason enrichment, publisher concentration, grouped-notice sensitivity, and DOI-linked notice structure.

The key interpretive limitation is the absence of publication-volume denominators. Raw counts therefore describe the Retraction Watch database and must not be presented as misconduct rates. Grouped notice events, evolving reason taxonomies, incomplete recent years, right truncation, and the multi-label nature of the data can all change the interpretation of headline trends.
